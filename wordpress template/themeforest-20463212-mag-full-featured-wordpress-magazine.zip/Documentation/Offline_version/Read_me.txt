For best experiene, please use online version of theme documentation: http://mnkythemedemos.com/documentation/mag/
Offline version is a plan B :)

To read offline version, unzip offline_documentation/ folder and open index file inside.