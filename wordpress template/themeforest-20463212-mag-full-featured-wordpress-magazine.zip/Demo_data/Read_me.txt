Demo data in these folders are meant for manual import. 
Please see online documentation for demo import options: http://mnkythemedemos.com/documentation/mag/